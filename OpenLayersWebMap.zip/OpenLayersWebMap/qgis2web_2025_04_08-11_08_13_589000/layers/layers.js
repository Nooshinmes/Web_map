var wms_layers = [];
var baseLayer = new ol.layer.Group({
    'title': '',
    layers: [
new ol.layer.Tile({
    'title': 'Stamen Terrain',
    'type': 'base',
    source: new ol.source.Stamen({
        layer: 'terrain'
    })
})
]
});
var format_municipalitiesG_0 = new ol.format.GeoJSON();
var features_municipalitiesG_0 = format_municipalitiesG_0.readFeatures(json_municipalitiesG_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_municipalitiesG_0 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_municipalitiesG_0.addFeatures(features_municipalitiesG_0);var lyr_municipalitiesG_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_municipalitiesG_0, 
                style: style_municipalitiesG_0,
    title: 'municipalitiesG<br />\
    <img src="styles/legend/municipalitiesG_0_0.png" /> CHEMAINUS 13<br />\
    <img src="styles/legend/municipalitiesG_0_1.png" /> COWICHAN VALLEY, SUBD. A<br />\
    <img src="styles/legend/municipalitiesG_0_2.png" /> COWICHAN VALLEY, SUBD. B<br />\
    <img src="styles/legend/municipalitiesG_0_3.png" /> COWICHAN VALLEY, SUBD. D<br />\
    <img src="styles/legend/municipalitiesG_0_4.png" /> LADYSMITH<br />\
    <img src="styles/legend/municipalitiesG_0_5.png" /> NANAIMO<br />\
    <img src="styles/legend/municipalitiesG_0_6.png" /> NANAIMO RIVER 2<br />\
    <img src="styles/legend/municipalitiesG_0_7.png" /> NANAIMO RIVER 3<br />\
    <img src="styles/legend/municipalitiesG_0_8.png" /> NANAIMO RIVER 4<br />\
    <img src="styles/legend/municipalitiesG_0_9.png" /> NANAIMO TOWN 1<br />\
    <img src="styles/legend/municipalitiesG_0_10.png" /> NANAIMO, SUBD. A<br />\
    <img src="styles/legend/municipalitiesG_0_11.png" /> NANAIMO, SUBD. B<br />\
    <img src="styles/legend/municipalitiesG_0_12.png" /> NANOOSE<br />\
    <img src="styles/legend/municipalitiesG_0_13.png" /> OYSTER BAY 12<br />\
    <img src="styles/legend/municipalitiesG_0_14.png" /> PARKSVILLE<br />\
    <img src="styles/legend/municipalitiesG_0_15.png" /> QUALICUM BEACH<br />\
    <img src="styles/legend/municipalitiesG_0_16.png" /> <br />'
        });var format_riversG_1 = new ol.format.GeoJSON();
var features_riversG_1 = format_riversG_1.readFeatures(json_riversG_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_riversG_1 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_riversG_1.addFeatures(features_riversG_1);var lyr_riversG_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_riversG_1, 
                style: style_riversG_1,
                title: '<img src="styles/legend/riversG_1.png" /> riversG'
            });var format_roadsG_2 = new ol.format.GeoJSON();
var features_roadsG_2 = format_roadsG_2.readFeatures(json_roadsG_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_roadsG_2 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_roadsG_2.addFeatures(features_roadsG_2);var lyr_roadsG_2 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_roadsG_2, 
                style: style_roadsG_2,
    title: 'roadsG<br />\
    <img src="styles/legend/roadsG_2_0.png" /> AVE<br />\
    <img src="styles/legend/roadsG_2_1.png" /> BAY<br />\
    <img src="styles/legend/roadsG_2_2.png" /> BLVD<br />\
    <img src="styles/legend/roadsG_2_3.png" /> BYPASS<br />\
    <img src="styles/legend/roadsG_2_4.png" /> CIR<br />\
    <img src="styles/legend/roadsG_2_5.png" /> CLOSE<br />\
    <img src="styles/legend/roadsG_2_6.png" /> CRES<br />\
    <img src="styles/legend/roadsG_2_7.png" /> CRT<br />\
    <img src="styles/legend/roadsG_2_8.png" /> DR<br />\
    <img src="styles/legend/roadsG_2_9.png" /> EXTEN<br />\
    <img src="styles/legend/roadsG_2_10.png" /> GATE<br />\
    <img src="styles/legend/roadsG_2_11.png" /> HILL<br />\
    <img src="styles/legend/roadsG_2_12.png" /> HWY<br />\
    <img src="styles/legend/roadsG_2_13.png" /> LANE<br />\
    <img src="styles/legend/roadsG_2_14.png" /> LKOUT<br />\
    <img src="styles/legend/roadsG_2_15.png" /> PKY<br />\
    <img src="styles/legend/roadsG_2_16.png" /> PL<br />\
    <img src="styles/legend/roadsG_2_17.png" /> RAMP<br />\
    <img src="styles/legend/roadsG_2_18.png" /> RD<br />\
    <img src="styles/legend/roadsG_2_19.png" /> RIDGE<br />\
    <img src="styles/legend/roadsG_2_20.png" /> ROW<br />\
    <img src="styles/legend/roadsG_2_21.png" /> RUN<br />\
    <img src="styles/legend/roadsG_2_22.png" /> SQ<br />\
    <img src="styles/legend/roadsG_2_23.png" /> ST<br />\
    <img src="styles/legend/roadsG_2_24.png" /> TERR<br />\
    <img src="styles/legend/roadsG_2_25.png" /> TRAIL<br />\
    <img src="styles/legend/roadsG_2_26.png" /> TRNABT<br />\
    <img src="styles/legend/roadsG_2_27.png" /> VIEW<br />\
    <img src="styles/legend/roadsG_2_28.png" /> WAY<br />\
    <img src="styles/legend/roadsG_2_29.png" /> <br />'
        });var format_lakesG_3 = new ol.format.GeoJSON();
var features_lakesG_3 = format_lakesG_3.readFeatures(json_lakesG_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_lakesG_3 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_lakesG_3.addFeatures(features_lakesG_3);var lyr_lakesG_3 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_lakesG_3, 
                style: style_lakesG_3,
                title: '<img src="styles/legend/lakesG_3.png" /> lakesG'
            });

lyr_municipalitiesG_0.setVisible(true);lyr_riversG_1.setVisible(true);lyr_roadsG_2.setVisible(true);lyr_lakesG_3.setVisible(true);
var layersList = [baseLayer,lyr_municipalitiesG_0,lyr_riversG_1,lyr_roadsG_2,lyr_lakesG_3];
lyr_municipalitiesG_0.set('fieldAliases', {'FID_VanIsl': 'FID_VanIsl', 'NAME': 'NAME', 'PROV': 'PROV', 'TYPE': 'TYPE', 'POP96': 'POP96', 'POP_SQKM': 'POP_SQKM', 'DWELL96': 'DWELL96', 'SHORE_AREA': 'SHORE_AREA', 'FID_Bounda': 'FID_Bounda', 'Id': 'Id', 'HTTP_URL': 'HTTP_URL', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_riversG_1.set('fieldAliases', {'FNODE_': 'FNODE_', 'TNODE_': 'TNODE_', 'LPOLY_': 'LPOLY_', 'RPOLY_': 'RPOLY_', 'LENGTH': 'LENGTH', 'RIVER0_': 'RIVER0_', 'RIVER0_ID': 'RIVER0_ID', 'Shape_Leng': 'Shape_Leng', });
lyr_roadsG_2.set('fieldAliases', {'FID_VanIsl': 'FID_VanIsl', 'STREET': 'STREET', 'FROMLEFT': 'FROMLEFT', 'TOLEFT': 'TOLEFT', 'FROMRIGHT': 'FROMRIGHT', 'TORIGHT': 'TORIGHT', 'PREDIR': 'PREDIR', 'PRETYPE': 'PRETYPE', 'STREETNAME': 'STREETNAME', 'SUFTYPE': 'SUFTYPE', 'SUFDIR': 'SUFDIR', 'CARTO': 'CARTO', 'LEFT_MUN': 'LEFT_MUN', 'RIGHT_MUN': 'RIGHT_MUN', 'LEFT_MAF': 'LEFT_MAF', 'RIGHT_MAF': 'RIGHT_MAF', 'LEFT_FSA': 'LEFT_FSA', 'RIGHT_FSA': 'RIGHT_FSA', 'LEFT_PRV': 'LEFT_PRV', 'RIGHT_PRV': 'RIGHT_PRV', 'UNIQUEID': 'UNIQUEID', 'FID_Bounda': 'FID_Bounda', 'Id': 'Id', 'Shape_Leng': 'Shape_Leng', });
lyr_lakesG_3.set('fieldAliases', {'AREA': 'AREA', 'PERIMETER': 'PERIMETER', 'LAKES0_': 'LAKES0_', 'LAKES0_ID': 'LAKES0_ID', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_municipalitiesG_0.set('fieldImages', {'FID_VanIsl': 'TextEdit', 'NAME': 'TextEdit', 'PROV': 'TextEdit', 'TYPE': 'TextEdit', 'POP96': 'TextEdit', 'POP_SQKM': 'TextEdit', 'DWELL96': 'TextEdit', 'SHORE_AREA': 'TextEdit', 'FID_Bounda': 'TextEdit', 'Id': 'TextEdit', 'HTTP_URL': 'TextEdit', 'Shape_Leng': 'TextEdit', 'Shape_Area': 'TextEdit', });
lyr_riversG_1.set('fieldImages', {'FNODE_': 'TextEdit', 'TNODE_': 'TextEdit', 'LPOLY_': 'TextEdit', 'RPOLY_': 'TextEdit', 'LENGTH': 'TextEdit', 'RIVER0_': 'TextEdit', 'RIVER0_ID': 'TextEdit', 'Shape_Leng': 'TextEdit', });
lyr_roadsG_2.set('fieldImages', {'FID_VanIsl': 'TextEdit', 'STREET': 'TextEdit', 'FROMLEFT': 'TextEdit', 'TOLEFT': 'TextEdit', 'FROMRIGHT': 'TextEdit', 'TORIGHT': 'TextEdit', 'PREDIR': 'TextEdit', 'PRETYPE': 'TextEdit', 'STREETNAME': 'TextEdit', 'SUFTYPE': 'TextEdit', 'SUFDIR': 'TextEdit', 'CARTO': 'TextEdit', 'LEFT_MUN': 'TextEdit', 'RIGHT_MUN': 'TextEdit', 'LEFT_MAF': 'TextEdit', 'RIGHT_MAF': 'TextEdit', 'LEFT_FSA': 'TextEdit', 'RIGHT_FSA': 'TextEdit', 'LEFT_PRV': 'TextEdit', 'RIGHT_PRV': 'TextEdit', 'UNIQUEID': 'TextEdit', 'FID_Bounda': 'TextEdit', 'Id': 'TextEdit', 'Shape_Leng': 'TextEdit', });
lyr_lakesG_3.set('fieldImages', {'AREA': 'TextEdit', 'PERIMETER': 'TextEdit', 'LAKES0_': 'TextEdit', 'LAKES0_ID': 'TextEdit', 'Shape_Leng': 'TextEdit', 'Shape_Area': 'TextEdit', });
lyr_municipalitiesG_0.set('fieldLabels', {'FID_VanIsl': 'no label', 'NAME': 'header label', 'PROV': 'no label', 'TYPE': 'no label', 'POP96': 'no label', 'POP_SQKM': 'no label', 'DWELL96': 'no label', 'SHORE_AREA': 'no label', 'FID_Bounda': 'no label', 'Id': 'no label', 'HTTP_URL': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_riversG_1.set('fieldLabels', {'FNODE_': 'no label', 'TNODE_': 'no label', 'LPOLY_': 'no label', 'RPOLY_': 'no label', 'LENGTH': 'header label', 'RIVER0_': 'no label', 'RIVER0_ID': 'no label', 'Shape_Leng': 'no label', });
lyr_roadsG_2.set('fieldLabels', {'FID_VanIsl': 'no label', 'STREET': 'header label', 'FROMLEFT': 'no label', 'TOLEFT': 'no label', 'FROMRIGHT': 'no label', 'TORIGHT': 'no label', 'PREDIR': 'no label', 'PRETYPE': 'no label', 'STREETNAME': 'no label', 'SUFTYPE': 'no label', 'SUFDIR': 'no label', 'CARTO': 'no label', 'LEFT_MUN': 'no label', 'RIGHT_MUN': 'no label', 'LEFT_MAF': 'no label', 'RIGHT_MAF': 'no label', 'LEFT_FSA': 'no label', 'RIGHT_FSA': 'no label', 'LEFT_PRV': 'no label', 'RIGHT_PRV': 'no label', 'UNIQUEID': 'no label', 'FID_Bounda': 'no label', 'Id': 'no label', 'Shape_Leng': 'header label', });
lyr_lakesG_3.set('fieldLabels', {'AREA': 'header label', 'PERIMETER': 'inline label', 'LAKES0_': 'no label', 'LAKES0_ID': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_lakesG_3.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});