var size = 0;
var placement = 'point';
function categories_roadsG_2(feature, value, size, resolution, labelText,
                       labelFont, labelFill) {
                switch(value.toString()) {case 'AVE':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(182,69,230,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'BAY':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(30,89,227,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'BLVD':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(209,110,67,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'BYPASS':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(214,104,92,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'CIR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(133,87,239,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'CLOSE':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(75,60,205,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'CRES':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(203,189,60,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'CRT':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(209,44,60,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'DR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(59,164,208,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'EXTEN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(126,213,187,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'GATE':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(195,230,114,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'HILL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(17,206,36,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'HWY':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(227,26,28,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 4}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'LANE':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(209,78,168,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'LKOUT':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(138,147,228,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'PKY':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(208,45,222,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'PL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(217,94,131,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'RAMP':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(224,44,134,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'RD':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(0,0,0,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'RIDGE':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(145,204,86,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'ROW':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(95,158,221,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'RUN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(209,166,65,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'SQ':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(44,200,91,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'ST':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(124,30,217,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'TERR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(210,119,28,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'TRAIL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(116,217,167,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'TRNABT':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(212,26,191,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'VIEW':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(127,234,115,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
case 'WAY':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(154,235,119,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;
default:
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(183,200,32,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement)
    })];
                    break;}};

var style_roadsG_2 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = feature.get("SUFTYPE");
    var labelText = "";
    size = 0;
    var labelFont = "10.725px \'MS Shell Dlg 2\', sans-serif";
    var labelFill = "rgba(0, 0, 0, 1)";
    var textAlign = "left";
    var offsetX = 8;
    var offsetY = 3;
    var placement = 'line';
    if ("" !== null) {
        labelText = String("");
    }
    
var style = categories_roadsG_2(feature, value, size, resolution, labelText,
                          labelFont, labelFill);

    return style;
};
